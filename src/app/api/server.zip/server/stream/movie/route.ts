import { NextResponse } from "next/server";
import puppeteer from "puppeteer";

export async function GET(request: Request) {
  const searchParams = new URL(request.url).searchParams;
  const encodedUrl = searchParams.get('url');

  if (!encodedUrl) {
    return NextResponse.json({ streams: [], error: "Parâmetro 'url' é obrigatório." }, { status: 400 });
  }

  let playerPageUrl: string;
  try {
    playerPageUrl = decodeURIComponent(encodedUrl);
    new URL(playerPageUrl);
  } catch (e) {
    console.error("[API/Stream/Movie] Erro: Parâmetro 'url' não é uma URL válida:", encodedUrl);
    return NextResponse.json({ streams: [], error: "Parâmetro 'url' fornecido não é uma URL válida." }, { status: 400 });
  }

  if (!playerPageUrl.includes("netcineo.lat") && !playerPageUrl.includes("neetcine.lat")) {
      return NextResponse.json({ streams: [], error: "URL não suportada." }, { status: 400 });
  }

  console.log(`[API/Stream/Movie] Iniciando automação com Puppeteer para: ${playerPageUrl}`);

  let browser;
  try {
    // Inicia o Puppeteer
    console.log("[API/Stream/Movie] Iniciando o navegador Puppeteer...");
    browser = await puppeteer.launch({
      headless: true, // Use 'false' para ver o navegador em ação durante o desenvolvimento
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process', // Descomente se estiver em um ambiente com poucos recursos
        '--disable-gpu'
      ],
    });
    const page = await browser.newPage();
    await page.setJavaScriptEnabled(false);
    await page.setDefaultNavigationTimeout(60000);
    await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
    await page.setExtraHTTPHeaders({
      'Referer': playerPageUrl.includes('neetcine.lat') ? 'https://neetcine.lat/' : 'https://netcineo.lat/',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
      'Accept-Encoding': 'gzip, deflate, br',
      'DNT': '1',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
    });

    // Navega para a página do player
    console.log(`[API/Stream/Movie] Navegando para ${playerPageUrl}`);
    let pageLoaded = false;
    try {
      await page.goto(playerPageUrl, { waitUntil: 'networkidle2', timeout: 60000 });
      pageLoaded = true;
    } catch (navError) {
      console.error(`[API/Stream/Movie] Erro de navegação: ${navError.message}`);
      // Tenta continuar se a página carregou parcialmente
      if (page.url() !== 'about:blank') {
        pageLoaded = true;
        console.log(`[API/Stream/Movie] Página carregou parcialmente: ${page.url()}`);
      }
    }
    if (!pageLoaded) {
      throw new Error(`Falha ao carregar a página: ${playerPageUrl}`);
    }
    console.log(`[API/Stream/Movie] Página carregada: ${page.url()}`);

    // Aguarda o player de vídeo estar presente na página
    const videoSelector = 'video#myvid, video'; // Tenta o ID específico ou qualquer tag de vídeo
    console.log(`[API/Stream/Movie] Aguardando pelo seletor de vídeo: ${videoSelector}`);
    await page.waitForSelector(videoSelector, { timeout: 20000 });

    // Extrai a URL do vídeo
    const videoSrc = await page.evaluate((sel) => {
      const videoElement = document.querySelector(sel);
      if (!videoElement) return null;
      const sourceElement = videoElement.querySelector('source');
      return sourceElement ? sourceElement.getAttribute('src') : videoElement.getAttribute('src');
    }, videoSelector);

    if (!videoSrc) {
      throw new Error("Não foi possível encontrar o 'src' do vídeo na página.");
    }

    console.log(`[API/Stream/Movie] URL do vídeo encontrada: ${videoSrc}`);

    // Coleta os cookies
    const cookies = await page.cookies();
    const cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
    console.log(`[API/Stream/Movie] Cookies coletados: ${cookieString}`);

    // Monta o objeto de stream
    const proxyUrl = `/api/server/video-proxy?videoUrl=${encodeURIComponent(videoSrc)}&headers=${encodeURIComponent(JSON.stringify({
      request: {
        "Referer": page.url(),
        "Cookie": cookieString || "XCRF=XCRF"
      }
    }))}`;
    const stream = {
      name: "NetCine (Puppeteer)",
      description: "Filme - Dublado (Scraped)",
      url: proxyUrl,
      proxyHeaders: {
        request: {
          "Referer": page.url(), // Usa a URL ATUAL da página como Referer
          "Cookie": cookieString || "XCRF=XCRF", // Usa os cookies coletados
        }
      },
    };

    return NextResponse.json({ streams: [stream] });

  } catch (error: any) {
    console.error(`[API/Stream/Movie] Erro durante a automação com Puppeteer:`, error.message || error);
    return NextResponse.json({ streams: [], error: "Ocorreu um erro inesperado durante a automação." }, { status: 500 });
  } finally {
    // Garante que o navegador seja fechado
    if (browser) {
      await browser.close();
      console.log("[API/Stream/Movie] Navegador Puppeteer fechado.");
    }
  }
}
