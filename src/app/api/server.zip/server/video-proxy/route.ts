import { NextResponse } from "next/server"

export const runtime = "nodejs"

// Headers that should never be forwarded or overridden
const BLOCKED_HEADERS = new Set([
"host",
"content-length",
"transfer-encoding",
"connection",
"keep-alive",
"upgrade",
"sec-fetch-mode",
"sec-fetch-site",
"sec-fetch-dest",
"sec-ch-ua",
"sec-ch-ua-mobile",
"sec-ch-ua-platform",
])

function sanitizeHeaders(input: Record<string, string> | undefined | null) {
const out: Record<string, string> = {}
if (!input) return out
for (const [k, v] of Object.entries(input)) {
  const key = k.toLowerCase()
  if (BLOCKED_HEADERS.has(key)) continue
  if (typeof v !== "string" || v.length === 0) continue
  out[key === "referer" ? "Referer" : key === "origin" ? "Origin" : k] = v
}
return out
}

// Build a couple of best-guess referers for sources like {sub}.{domain}.{tld}
function buildRefererCandidates(target: URL): string[] {
const hostParts = target.hostname.split(".")
const baseDomain =
  hostParts.length >= 2 ? `${hostParts.slice(-2).join(".")}` : target.hostname
const rootOrigin = `${target.protocol}//${baseDomain}`
const assetOrigin = `${target.protocol}//${target.hostname}`
// Ensure trailing slash where appropriate
const ensureSlash = (u: string) => (u.endsWith("/") ? u : `${u}/`)
const candidates = [ensureSlash(rootOrigin), ensureSlash(assetOrigin)]
// De-duplicate while preserving order
return Array.from(new Set(candidates))
}

async function proxyOnce(videoUrl: string, headersToSend: Record<string, string>) {
  const response = await fetch(videoUrl, {
    headers: headersToSend,
  });

  const headersObj: Record<string, string> = {};
  response.headers.forEach((value, key) => {
    headersObj[key] = value;
  });

  if (!response.ok) {
    return {
      ok: false,
      status: response.status,
      headers: headersObj,
      buffer: null
    };
  }

  const buffer = Buffer.from(await response.arrayBuffer());

  return {
    ok: true,
    status: response.status,
    headers: headersObj,
    buffer
  };
}

export async function GET(request: Request) {
const { searchParams } = new URL(request.url)
const videoUrl = searchParams.get("videoUrl")
const encodedHeaders = searchParams.get("headers")
const rangeHeader = request.headers.get("range")

if (!videoUrl) {
  return new NextResponse("URL do vídeo não fornecida.", { status: 400 })
}

let target: URL
try {
  target = new URL(videoUrl)
} catch {
  return new NextResponse("URL do vídeo inválida.", { status: 400 })
}

console.log(`[VideoProxy] Proxying request to: ${videoUrl}`)

// Base headers
const headersToSend: Record<string, string> = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Accept": "*/*",
  "Accept-Language": "pt-BR,pt;q=0.5",
  "Accept-Encoding": "identity;q=1, *;q=0",
  "Connection": "keep-alive",
  "Cookie": "PHPSESSID=99aab9a79d80ddkn1l3k242m00; XCRF=XCRF", // Adicionado cookie exigido pelo provedor
}

// Merge user-provided headers (stream may provide proxyHeaders or proxyHeaders.request)
if (encodedHeaders) {
  try {
    const decoded = JSON.parse(decodeURIComponent(encodedHeaders))
    const maybeRequest = decoded?.request && typeof decoded.request === "object" ? decoded.request : decoded
    const provided = sanitizeHeaders(maybeRequest)
    Object.assign(headersToSend, provided) // Merge provided headers, allowing them to override
    console.log("[VideoProxy] Using provided headers (sanitized):", provided)
  } catch (e) {
    console.error("[VideoProxy] Erro ao decodificar cabeçalhos:", e)
  }
}

// Adiciona o Referer específico se o domínio for neetcine.lat
// if (target.hostname.endsWith("neetcine.lat")) {
//   headersToSend["Referer"] = "https://neetcine.lat/"
//   console.log(`[VideoProxy] Using specific Referer for neetcine.lat: ${headersToSend["Referer"]}`)
// }

// Adiciona Origin para neetcine.lat
if (target.hostname.endsWith("neetcine.lat")) {
  headersToSend["Origin"] = "https://neetcine.lat"
  console.log(`[VideoProxy] Using Origin for neetcine.lat: ${headersToSend["Origin"]}`)
}

// Forward Range if present
if (rangeHeader) {
  headersToSend["Range"] = rangeHeader
  console.log(`[VideoProxy] Forwarding Range header: ${rangeHeader}`)
}

try {
  console.log(`[VideoProxy] Attempting fetch with Referer: ${headersToSend.Referer || "none"}`)
  const res = await proxyOnce(videoUrl, headersToSend)
  console.log(`[VideoProxy] Upstream response status: ${res.status}`)

  if (res.ok) {
    // Build response to client
    const responseHeaders = new Headers()
    const contentType = res.headers["content-type"] || res.headers["Content-Type"]
    const contentLength = res.headers["content-length"] || res.headers["Content-Length"]
    const acceptRanges = res.headers["accept-ranges"] || res.headers["Accept-Ranges"]
    const contentRange = res.headers["content-range"] || res.headers["Content-Range"]

    if (contentType) responseHeaders.set("Content-Type", contentType)
    if (contentLength) responseHeaders.set("Content-Length", contentLength)
    if (acceptRanges) responseHeaders.set("Accept-Ranges", acceptRanges)
    if (contentRange) responseHeaders.set("Content-Range", contentRange)

    // No-cache for streaming
    responseHeaders.set("Cache-Control", "no-cache, no-store, must-revalidate")
    responseHeaders.set("Pragma", "no-cache")
    responseHeaders.set("Expires", "0")

    // CORS
    responseHeaders.set("Access-Control-Allow-Origin", "*")
    responseHeaders.set("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
    responseHeaders.set("Access-Control-Allow-Headers", "Range, Content-Type")
    responseHeaders.set("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges")

    return new NextResponse(res.buffer as any, {
      status: res.status,
      statusText: "OK",
      headers: responseHeaders,
    })
  }

  // Handle non-ok responses
  const body = "Erro no proxy"
  console.error(`[VideoProxy] Upstream error ${res.status}: ${body}`)
  return new NextResponse(`Falha ao carregar vídeo: ${res.status}`, {
    status: res.status,
  })
} catch (error: any) {
  console.error(`[VideoProxy] Fetch failed:`, error?.message || error)
  return new NextResponse("Não foi possível alcançar o provedor de vídeo.", { status: 502 })
}
}

// Preflight and CORS
export async function OPTIONS() {
return new NextResponse(null, {
  status: 200,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-control-allow-headers": "Range, Content-Type",
    "Access-Control-Max-Age": "86400",
  },
})
}
